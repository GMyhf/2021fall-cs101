// array.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include <stdio.h>

int main(int argc, char* argv[])
{
	int n,i,j,array[2000][2000],count=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			scanf("%d",&array[i][j]);
	for(i=1;i<n-1;i++)
		for(j=1;j<n-1;j++){
			if(array[i-1][j]>=array[i][j]+50 
				&& array[i+1][j]>=array[i][j]+50
				&& array[i][j-1]>=array[i][j]+50 
				&& array[i][j+1]>=array[i][j]+50 ) 
				count++;
		}
	printf("%d\n",count);
	return 0;
}

