#include <iostream>
#include <fstream>
#include <algorithm>
#include <cassert>

using namespace std;


int a[100],b[100];

int n;

void solve(int* a,int* save){
	a[0]=1;
	int i,j;
	for(i=1;i<n;i++){
		a[i]=1;
		for(j=0;j<n;j++){
			if(save[j]<save[i]&&a[i]<a[j]+1)
				a[i]=a[j]+1;
		}
	}
}

int main(){
	int save[100];
	int i,j;
	cin>>n;
	assert(2<=n&&n<=100);
	for(i=0;i<n;i++){
		cin>>save[i];
		assert(130<=save[i]&&save[i]<=230);
	}
	solve(a,save);
	std::reverse(save,save+n);
	solve(b,save);
	int max=-1;
	for(i=0;i<n;i++){
		if(a[i]+b[n-1-i]-1>max)max=a[i]+b[n-1-i]-1;
	}
	cout<<n-max<<'\n';
	assert(!(cin>>n));
	return 0;
}
