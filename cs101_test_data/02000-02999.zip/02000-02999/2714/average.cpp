#include <stdio.h>

void main()
{
	int n, i, a, sum=0;
	float ava;

	scanf("%d", &n);

	for(i=1; i<=n; i++)
	{
		scanf("%d", &a);
		sum += a;
	}

	ava = 1.0f*sum/n;

	printf("%.2f\n", ava);
}

