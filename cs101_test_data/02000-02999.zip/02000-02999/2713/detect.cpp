#include <stdio.h>

int image[1000][1000];

void main()
{
	int n, i, j, bi, bj, ei, ej, isBreak;

	scanf("%d", &n);

	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			scanf("%d", &image[i][j]);
		}
	}

	isBreak = 0;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(image[i][j]==0)
			{
				bi = i;
				bj = j;
				isBreak = 1;
				break;
			}
		}
		if( isBreak==1 )  break;
	}

	for(i = bi; j<n; i++)
	{
		if( image[i][bj]!=0 )
		{
			ei = i - 1;
			break;
		}
	}

	for(j = bj; j<n; j++)
	{
		if( image[bi][j]!=0 )
		{
			ej = j - 1;
			break;
		}
	}

	printf("%d\n", (ej-bj-1)*(ei-bi-1));
}
