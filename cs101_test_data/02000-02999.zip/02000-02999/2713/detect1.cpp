// task2.cpp : Defines the entry point for the console application.
//

#include <stdio.h>

int picture[1000][1000];

void main( )
{
	int size;
	scanf("%d",&size);
	int i,j;
	for(i=0;i<size;i++)
		for(j=0;j<size;j++)
			scanf("%d",&picture[i][j]);

	int tag=0;
	int starti,startj;
	for(i=0;i<size && tag==0;i++)
		for(j=0;j<size && tag==0;j++)
			if(picture[i][j]==0){
				tag=1;
				starti=i;
				startj=j;
			}
    tag=0;
	int endi,endj;
	for(i=size-1;i>=0 && tag==0;i--)
		for(j=size-1;j>=0 && tag==0;j--)
			if(picture[i][j]==0){
				tag=1;
				endi=i;
				endj=j;
			}
	
    printf("%d\n",(endi-starti-1)*(endj-startj-1));

}
