n = int(input())

D = list(map(float, input().split()))

min_val = D[0]
max_val = 1

for i in range(1, n):
    max_val = max(max_val, D[i]/min_val)
    min_val = min(D[i], min_val)

print("%.2f" % (100*max_val))