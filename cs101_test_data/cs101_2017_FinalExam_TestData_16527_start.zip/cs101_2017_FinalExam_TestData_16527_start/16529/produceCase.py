import random
import sys
import os

# if len(sys.argv) != 2:
#     print("Usage: produceCase.py caseNum\n无输入程序将使用使用默认case数量20")
#     caseNum = 20
# else:
#     caseNum = int(sys.argc[1])

caseNum = 20

for i in range(caseNum):
    with open(str(i+1) + ".in", "w") as fout:
        a = int(random.randint(1, 100000))
        print(a, file=fout)
        for j in range(a):
            print("%.4f" % (random.random()* 1000 + 0.0001), file=fout, end=' ')
        print(file=fout)


    os.system("python sampleCode.py < %d.in > %d.out" %(i+1, i+1))
