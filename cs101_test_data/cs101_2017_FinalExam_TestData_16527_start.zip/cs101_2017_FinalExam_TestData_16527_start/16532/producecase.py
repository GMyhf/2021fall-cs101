import numpy.random as random
dir = [[-1,-1],[-1,1],[1,-1],[1,1]]
bags = [[0,0],[8,0],[16,0],[0,5],[8,5],[16,5]]
for i in range(1,10):
    f = open(str(i)+".in", "w")
    w = open(str(i)+".out","w")

    wx = random.randint(1,16)
    wy = random.randint(1,5)

    bx = random.randint(1,16)
    by = random.randint(1,5)
    while wx==bx and wy==by:
        bx = random.randint(1,16)
        by = random.randint(1,5)

    dirIndex = random.randint(0,4)
    dirx, diry = dir[dirIndex]
    energy = random.randint(0,50)

    f.write(str(wx)+" "+str(wy)+"\n")
    f.write(str(bx)+" "+str(by)+"\n")
    f.write(str(dirx)+" "+str(diry)+"\n")
    f.write(str(energy)+"\n")
    f.close()

    cnt = 0
    BallInBag = 0
    for j in range(0,energy):
        wx = wx + dirx
        wy = wy + diry

        #go in bag
        if [wx,wy] in bags:
            BallInBag = 1
            if cnt%2 == 0:
                w.write("-1")
            else:
                w.write("1")
            break
        #record how many times white and black ball hit  
        if wx == bx and wy == by:
            cnt = cnt+1 
        #reflect 
        if (wx == 0 and dirx == -1) or (wx == 16 and dirx == 1):
            dirx = -dirx
        if (wy == 0 and diry == -1) or (wy == 5 and diry == 1):
            diry = -diry

    if BallInBag == 0:
        w.write("0")
    w.close()