#python 2.x

wx, wy = [int(i) for i in raw_input().split()]
bx, by = [int(i) for i in raw_input().split()]
dirx, diry = [int(i) for i in raw_input().split()]
energy = int(raw_input())

bags = [[0,0],[8,0],[16,0],[0,5],[8,5],[16,5]]

cnt = 0
BallInBag = 0
for i in range(0,energy):
    wx = wx + dirx
    wy = wy + diry

    #go in bag
    if [wx,wy] in bags:
        BallInBag = 1
        if cnt%2 == 0:
            print -1
        else:
            print 1
        break
    #record how many times white and black ball hit  
    if wx == bx and wy == by:
        cnt = cnt+1 
    #reflect 
    if (wx == 0 and dirx == -1) or (wx == 16 and dirx == 1):
        dirx = -dirx
    if (wy == 0 and diry == -1) or (wy == 5 and diry == 1):
        diry = -diry

if BallInBag == 0:
    print 0
