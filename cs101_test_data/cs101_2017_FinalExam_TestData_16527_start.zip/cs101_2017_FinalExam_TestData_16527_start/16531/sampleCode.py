data = []
examRecord = []
[m, n] = list(map(int, input().split()))
for i in range(m):
    data.append(list(map(int, input().split())))
for i in range(m*n):
    examRecord.append(list(map(int, input().split())))

num1 = 0
for i in range(m):
    for j in range(n):
        if i > 0 and examRecord[data[i][j]] == examRecord[data[i-1][j]]: num1+=1
        elif i < m-1 and examRecord[data[i][j]] == examRecord[data[i+1][j]]: num1+=1
        elif j > 0 and examRecord[data[i][j]] == examRecord[data[i][j-1]]: num1 += 1
        elif j < n - 1 and examRecord[data[i][j]] == examRecord[data[i][j+1]]:num1 += 1

num2 = 0
correctCount = [0] * (len(examRecord[0])+1)
for i in examRecord:
    correctCount[i.count(1)] += 1


for i in correctCount[::-1]:
    if float(num2 + i)/(m*n) <= 0.4:
        num2 += i
    else:
        break

print(num1, num2)