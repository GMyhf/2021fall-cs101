n = int(input())
while n != 0:
    words = []
    for i in range(n):
        words.append(str(input()))
    list.sort(words)
    k = int(n / 2)
    mid, afterMid = words[k - 1 : k + 1]
    ok = False
    rst = ""
    temp = ""
    cur = 0
    length = len(mid)
    while cur < length:
        for i in range(26):
            rst = temp
            rst += chr(i + 65)
            if rst >= mid and rst < afterMid:
                ok = True
                break
        if ok:
            break
        temp += mid[cur]
        cur += 1
    print(rst)
    n = int(input())
