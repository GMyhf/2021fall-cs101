import sys
n=int(input())

res=[[0 for j in range(n)] for i in range(n)]
i,j=[0,0]
u,d,l,r=[0,n-1,0,n-1] 
idx=1
flag=0 # indicate direction
while u<=d and l<=r:
  if flag==0:
    while j<=r:
      res[i][j] = idx
      j+=1
      idx+=1
    u+=1
    j-=1
    i+=1
  elif flag==1:
    while i<=d:
      res[i][j] = idx
      i+=1
      idx+=1
    r-=1
    i-=1
    j-=1
  elif flag==2:
    while j>=l:
      res[i][j] = idx
      j-=1
      idx+=1
    d-=1
    j+=1
    i-=1
  else:   # flag==3
    while i>=u:
      res[i][j] = idx
      i-=1
      idx+=1
    l+=1
    i+=1
    j+=1
  flag = (flag+1) & 3 #(flag+1)%4
  
# output
for i in range(n):
  print(' '.join([str(j) for j in res[i]]))