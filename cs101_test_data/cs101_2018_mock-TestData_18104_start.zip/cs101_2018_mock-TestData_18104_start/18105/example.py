citations=[int(i) for i in input().split()]

st=sorted(citations)
n=len(st)
res=0
for i in range(0,n):
  h=n-i
  if st[i]>=h:
    res=h
    break
print(res)