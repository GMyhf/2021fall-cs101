from random import Random
import math

def random_str(randomlength=8):
    str = ''
    chars = '0123456789.'
    length = len(chars) - 1
    random = Random()
    for i in range(randomlength):
        str+=chars[random.randint(0, length)]
    return str

def isPrime(n):
	if n <= 1:
		return False
	for i in range(2, int(math.sqrt(n)) + 1):
		if n % i == 0:
			return False
	return True

def produce(n, filename):
	with open(filename+".in", 'w+') as output:
		output.write(str(n)+"\n")
		for i in range(n):
			random = Random()
			start = random.randint(1, 5000)
			end = random.randint(start, 5000)
			output.write(str(start) + " " + str(end) + "\n")

filename="4"
produce(50, filename)

input = open(filename+".in")
output = open(filename + ".out", "w+")
lines = input.readlines()
T = int(lines[0])
for l in range(1, len(lines)):
	ans = []
	start, end = map(int, lines[l].split())
	for i in range(start, end+1):
		if isPrime(i):
			ans.append(i)
	if len(ans) != 0:
		output.write(' '.join(map(str, ans)) + "\n")
	else:
		output.write("-1\n")