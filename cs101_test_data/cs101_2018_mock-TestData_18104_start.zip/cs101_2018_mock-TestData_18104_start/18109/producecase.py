from random import Random
def random_str(randomlength):
	output1 = open(filename + ".in", "w+")
	str = ''
	chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz'
	length = len(chars) - 1
	random = Random()
	for i in range(randomlength):
		str+=chars[random.randint(0, length)]
	output1.write(str)


filename = "6"
random_str(2500)



input = open(filename + ".in")
sentence = input.readlines()[0].lower()
list = []
count = 1
dic={}
for i in range(len(sentence)):
	if(dic.has_key(sentence[i])):
		dic[sentence[i]]+=1
	else:
		dic[sentence[i]] = 1

chars_out=''
chars_num=0
for key in dic:
	if(dic[key]>chars_num):
		chars_out=key
		chars_num=dic[key]

with open(filename + ".out", 'w+') as output:
	output.write(chars_out+" "+ str(chars_num))