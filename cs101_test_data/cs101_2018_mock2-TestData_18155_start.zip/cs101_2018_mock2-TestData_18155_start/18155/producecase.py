from random import randint, shuffle


def DFS(S, T, cur_state, is_null, cur_pos):
    if is_null == False and cur_state == T:
        return True

    if cur_pos == len(S):
        return False

    if DFS(S, T, cur_state * S[cur_pos], False, cur_pos + 1):
        return True

    if DFS(S, T, cur_state, is_null, cur_pos + 1):
        return True

    return False


def shuffle_select(S):
    S_copy = list(S)
    shuffle(S_copy)

    T = 1
    n = randint(1, len(S_copy))

    for i in range(0, n):
        T *= S_copy[i]

    return T


##################################################################



for case_id in range(1, 51):

    N = randint(0, 16)

    S = set()
    while len(S) < N:
        S.add(randint(0, 65535))

    res = randint(0, 1)
    if res == 1:
        T = shuffle_select(S)
    else:
        T = randint(0, 65535)

    fin = open(str(case_id)+".in", "w")
    fin.write(str(T) + "\n")
    for ele in S:
        fin.write(str(ele) + " ")

    if res != DFS(list(S), T, 1, True, 0):
        print("Error in produce case!")

    fin = open(str(case_id) + ".in", "w")
    fin.write(str(T) + "\n")
    for ele in S:
        fin.write(str(ele) + " ")

    fout = open(str(case_id) + ".out", "w")
    if res == 1:
        fout.write("YES")
    else:
        fout.write("NO")

