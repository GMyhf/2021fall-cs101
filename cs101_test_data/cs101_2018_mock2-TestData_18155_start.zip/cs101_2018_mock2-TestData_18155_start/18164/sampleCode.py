N = int(input())
pieces = [int(x) for x in input().split()]
list.sort(pieces)
ans = 0
while len(pieces) > 1:
    l1 = pieces[0]
    l2 = pieces[1]
    ans += l1 + l2
    pieces.remove(l1)
    pieces.remove(l2)
    pieces.append(l1+l2)
    list.sort(pieces)
print(ans)
