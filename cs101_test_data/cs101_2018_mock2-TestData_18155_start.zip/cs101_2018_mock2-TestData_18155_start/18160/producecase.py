from random import Random
import math

def produce(T, filename,r,c):
	random = Random()
	with open(filename+".in", 'w+') as output:
		output.write(str(T)+"\n")
		for t in range(T):
			N = random.randint(1, r)
			M = random.randint(1, c)
			output.write(str(N) + " " + str(M) + "\n")
			tmpStr='.W..'
			for j in range(N):
				for i in range(M):
					output.write(tmpStr[(random.randint(0, 3))])
				output.write("\n")

dir = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]]
def dfs(x, y,nums):
	if x < 0 or x >= N or y < 0 or y >= M or board[x][y] != 'W':
		return
	board[x][y] = '.'
	nums[0]+=1
	for i in range(len(dir)):
		dfs(x + dir[i][0], y + dir[i][1],nums)
	


filename="6"
cell_rows=40
cell_cols=50
produce(200, filename,cell_rows,cell_cols)



input = open(filename+".in")
output = open(filename + ".out", "w+")
lines = input.readlines()

T = int(lines[0])
####
l = 1
while l < len(lines):
	N, M = map(int, lines[l].split())
	l += 1
	board = []
	nums=[]
	nums.append(0)
	nums[0]=0
	temp_counts = 0
	ans = 0
	for i in range(N):
		board.append(list(lines[l]))
		l += 1
	for i in range(N):
		for j in range(M):
			if board[i][j] == 'W':
				dfs(i, j,nums)
				if(ans<nums[0]):
					ans=nums[0]
			# print("i ,j is =", i, j, nums[0])
			nums[0]=0
	# output.write(str(N)+"--"+str(M)+ "\n")
	output.write(str(ans)+"\n")
