dir = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]]
def dfs(x, y):
	if x < 0 or x >= N or y < 0 or y >= M or board[x][y] != 'W':
		return
	board[x][y] = '.'
	nums[0]+=1
	for i in range(len(dir)):
		dfs(x + dir[i][0], y + dir[i][1],nums)
	


T = int(input())
print("T is =:",T)
while T!=0:
	T -= 1	
	N, M = map(int, input().split())
	print("N is =:",N)
	board = []
	nums=[]
	nums.append(0)
	ans = 0
	for i in range(N):
		board.append(list(input()))
	for i in range(N):
		for j in range(M):
			if board[i][j] == 'W':
				dfs(i, j,nums)
				if(nums[0]>ans):
					ans=nums[0]
	print(ans)