T = int(input())

data = input()
S = [int(ele) for ele in data.split()]


def solve(S, T):

    S.sort()

    i = 0
    j = len(S) - 1

    res = S[i] + S[j]
    while i < j:
        cur_val = S[i] + S[j]

        if abs(cur_val - T) < abs(res - T):
            res = cur_val

        if abs(cur_val - T) == abs(res - T) and cur_val < res:
            res = cur_val

        if cur_val == T:
            break
        elif cur_val < T:
            i = i + 1
        else:
            j = j - 1

    return res

print(solve(S, T))

