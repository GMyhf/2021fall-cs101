import random
import sys
import os
import string
caseNumber = 10
for i in range(caseNumber):
    with open(str(i+1)+".in", "w") as f:
        # input cases number
        N = int(random.randint(1, 100))
        print(N, file = f)
        for j in range(N):
            # the period of a string
            period = int(random.randint(1,50))
            # substring
            ran_str = "".join(random.sample(string.ascii_letters, period))
            length = int(random.randint(1, 100))
            ran_input = ""
            if length >= period:
                for k in range(int(length / period)):
                    ran_input = ran_input + ran_str
            else:
                ran_input = ran_str
            print(ran_input, file = f)
    os.system("python3 sampleCode.py <%d.in> %d.out" %(i+1,i+1))
