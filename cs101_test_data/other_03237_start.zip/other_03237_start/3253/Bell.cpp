#include <iostream>
using namespace std;
int combine(int n,int k)
{
	int r=1;
	if(k>n/2) 
		k=n-k;
	for(int i=n; i>=n-k+1; i--) 
		r*=i;
	for(int i=1; i<=k; i++) 
		r/=i;
	return r;
}

int main()
{
	int n;
	int bell[16];
	while (cin >> n) {
		bell[0]=1;
		for(int i=1; i<=n; i++) {
			bell[i]=0;
			for(int j=0; j<i; j++)
				bell[i]+=bell[j]*combine(i-1,j);
		}
		cout << bell[n] << endl;
	}
}
