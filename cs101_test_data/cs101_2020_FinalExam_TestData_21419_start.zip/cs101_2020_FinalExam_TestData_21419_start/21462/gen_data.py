import math


with open('data.txt', 'r') as f:
    texts = f.readlines()

for ii in range(len(texts)):
    text = texts[ii].strip('\n')
    with open('data/' + str(ii + 1) + '.out', 'w') as f:
        f.write(text)

    ascii_text = [ord(c) for c in text]
    text_len = len(ascii_text)

    n = math.ceil(math.sqrt(text_len))
    lines = [str(n) + '\n']

    matrix = [[0] * n for j in range(n)]
    record = [[0] * (n + 2) for j in range(n + 2)]
    for i in range(n + 2):
        record[i][0] = 1
        record[i][n + 1] = 1
        record[0][i] = 1
        record[n + 1][i] = 1

    moves = [[1, 0], [0, 1], [-1, 0], [0, -1]]
    direction = 0

    cur_x = 0
    cur_y = 0

    for char in text:
        matrix[cur_x][cur_y] = ord(char)

        record[cur_x + 1][cur_y + 1] = 1

        if record[cur_x + moves[direction][0] + 1][cur_y + moves[direction][1] + 1] == 1:
            direction = (direction + 1) % 4

        cur_x = cur_x + moves[direction][0]
        cur_y = cur_y + moves[direction][1]

    for i in range(n):
        lines.append(' '.join([str(matrix[i][j]) for j in range(n)]))
        lines[-1] = lines[-1] + '\n'

    with open('data/' + str(ii + 1) + '.in', 'w') as f:
        f.writelines(lines)