# -*- coding: utf-8 -*-
"""
Created on Sat Dec 7 15:33:05 2019

@author: huyang
"""

import random
import os

caseNum = 20

for i in range(caseNum):
    with open(str(i+1)+".in", "w") as fout:
        n = int(random.randint(1, 300))
        print(n, file=fout)
        
        for j in range(n):
            print('%d'%random.randint(1, 1000), file=fout, end=' ')
        print(file=fout)

    os.system("python sampleCode.py < %d.in > %d.out" %(i+1, i+1))


