import random
from solution import solve


def get_rand(a, b):
    return random.randint(a, b)


def process_input():
    for i in range(1, 21):
        with open("./data/" + str(i) + ".in", "w") as f:
            n = get_rand(1, 5000)
            w = get_rand(1, 5000)

            p = get_rand(1, 200)
            q = get_rand(1, 200)

            print(n, w, file=f)
            print(p, q, file=f)

            for j in range(n - 1):
                x = get_rand(0, 1000)
                y = get_rand(0, 70)
                print(x, y, file=f)

            x = get_rand(0, 1000)
            y = get_rand(0, 70)
            print(x, y, end="", file=f)


def process_output():
    for i in range(1, 21):
        with open("./data/" + str(i) + ".in", "r") as f:
            n, w = map(int, f.readline().split())
            p, q = map(int, f.readline().split())
            arr = []
            for j in range(n):
                x, y = map(int, f.readline().split())
                arr.append([x, y])

            with open("./data/" + str(i) + ".out", "w") as fw:
                print(solve(n, w, p, q, arr), end="", file=fw)


if __name__ == "__main__":
    # process_input()
    # process_output()
    n = get_rand(1, 10)
    w = get_rand(1, 30)

    p = get_rand(1, 200)
    q = get_rand(1, 200)

    print(n, w)
    print(p, q)

    arr = []
    for j in range(n):
        x = get_rand(0, 200)
        y = get_rand(0, 20)
        arr.append([x, y])
        print(x, y)

    print("res = %d" % solve(n, w, p, q, arr))
