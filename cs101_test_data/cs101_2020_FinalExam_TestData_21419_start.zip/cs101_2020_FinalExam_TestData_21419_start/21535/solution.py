'''
贪心
只需要去打败 P + Q >= x + y 的怪兽，所以先把 x + y 不符合条件的怪兽去掉
将 x + y 的结果进行从小到大排序，每次只需要打最小的
'''


def solve(n, w, p, q, arr):
    beat = []
    for t in arr:
        if t[0] <= p + q:
            beat.append(t[1])
    beat.sort()

    ans = 0
    for t in beat:
        if (w >= t):
            w -= t
            ans += 1
        else:
            break
    return ans


if __name__ == "__main__":
    n, w = map(int, input().split())
    p, q = map(int, input().split())
    arr = []
    for i in range(n):
        x, y = map(int, input().split())
        arr.append([x, y])
    print(solve(n, w, p, q, arr))
