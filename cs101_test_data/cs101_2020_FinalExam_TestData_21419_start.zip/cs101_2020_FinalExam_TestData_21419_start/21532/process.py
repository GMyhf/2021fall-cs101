import random
from solution import solve


def get_rand(a, b):
    return random.randint(a, b)


# process inputdata
with open("./data/1.in", "w") as f:
    print(1000000007, end="", file=f)

with open("./data/2.in", "w") as f:
    print(2**30, end="", file=f)

with open("./data/3.in", "w") as f:
    print(1024, end="", file=f)

with open("./data/4.in", "w") as f:
    print(6, end="", file=f)

with open("./data/5.in", "w") as f:
    print(56, end="", file=f)

with open("./data/6.in", "w") as f:
    print(36, end="", file=f)

for i in range(7, 21):
    path = "./data/" + str(i) + ".in"
    with open(path, "w") as f:
        sum = get_rand(1, 100000)
        print(sum, end="", file=f)

# process outputdata
for i in range(1, 21):
    with open("./data/" + str(i) + ".in", "r") as f:
        sum = int(f.readline())
        ans = solve(sum)
        with open("./data/" + str(i) + ".out", "w") as fw:
            print(ans, end="", file=fw)
