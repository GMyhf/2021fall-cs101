
for _ in range(13, 20):
    f = open("C" + str(_) + ".in", "r")
    fw = open("C" + str(_) + ".out", "w")
    T, n = [int(x) for x in f.readline().split()]#input().split()]
    t = []
    w = []
    for i in range(n):
        a, b = [int(x) for x in f.readline().split()]
        t.append(a);
        w.append(b);
    
    dp = [0] + [-1] * T
    for i in range(n):
        for j in range(T, 0, -1):
            if j >= t[i] and dp[j - t[i]] != -1:
                dp[j] = max(dp[j], dp[j - t[i]] + w[i])
    
    print(dp[T], file = fw)
    
