#include <bits/stdc++.h>

int getRand(int R) {
    return rand() * rand() % R + 1;
}

int main()
{
    srand(time(NULL));
    // printf("%d", RAND_MAX);

    for (int i = 13; i < 20; ++ i) {
        freopen((std::string("C") + std::to_string(i) + std::string(".in")).c_str(), "w", stdout);
        int T, n;
        T = getRand(1000);
        n = getRand(1000);
        std::cout << T << ' ' << n << std::endl;
        for (int i = 1; i <= n; ++ i) {
            std::cout << getRand(T) << ' ' << getRand(20) << std::endl;
        }
    }

}
