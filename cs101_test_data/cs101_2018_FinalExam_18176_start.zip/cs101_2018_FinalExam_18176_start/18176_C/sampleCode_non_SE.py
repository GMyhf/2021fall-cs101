from math import sqrt

# input n >= 2
def isPrime(n):
	for i in range(2, int(sqrt(n) + 1)):
		if n % i == 0:
			return False
	return True


m, n = [int(i) for i in input().split()]

for i in range(m):
	x = [int(i) for i in input().split()]
	sum = 0
	for num in x:
		root = int(sqrt(num))
		if num > 3 and isPrime(root) and num == root * root:
			sum += num
	sum /= len(x)
	if sum == 0:
		print(0)
	else:
		print('%.2f' % sum)







