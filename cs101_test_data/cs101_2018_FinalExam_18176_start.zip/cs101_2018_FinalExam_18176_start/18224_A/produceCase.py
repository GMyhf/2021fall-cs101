import random
import os

l = []
i = 1
while i*i < 1000:
    l.append(i*i)
    i += 1

magics = []
for i in l:
    for j in l:
        magics.append(i+j)

caseNum = 20
R = random.randint
S = random.shuffle
for i in range(caseNum):
    with open(str(i+1) + ".in", "w") as fout:
        m = R(1, 100)
        print(m, file=fout)
        p = R(1, m//2)
        S(magics)
        data = magics[:p] + [R(1,1000) for i in range(m-p)]

        data = [str(num) for num in data]
        print(' '.join(data), file=fout)

    os.system("python sampleCode.py < %d.in > %d.out" %(i+1, i+1))