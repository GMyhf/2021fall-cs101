from random import Random
import math

def produce(n, filename):
	with open(filename+".in", 'w+') as output:
		output.write(str(n)+"\n")
		random = Random()
		for i in range(n-1):
			output.write(str(random.randint(1, 10000)/float(100.0)) + " ")
		output.write(str(random.randint(1, 10000)/float(100.0)))

import math
import functools

def percentile(N, percent, key=lambda x:x):
    """
    Find the percentile of a list of values.

    @parameter N - is a list of values. Note N MUST BE already sorted.
    @parameter percent - a float value from 0.0 to 1.0.
    @parameter key - optional key function to compute value from each element of N.

    @return - the percentile of the values
    """
    if not N:
        return None
    k = (len(N)-1) * percent
    f = math.floor(k)
    c = math.ceil(k)
    if f == c:
        return key(N[int(k)])
    d0 = key(N[int(f)]) * (c-k)
    d1 = key(N[int(c)]) * (k-f)
    return d0+d1

filename="3"
#produce(100, filename)

input = open(filename+".in")
output = open(filename + ".out", "w+")
lines = input.readlines()
n =  int(lines[0])
nums = [float(i) for i in lines[1].split()]
nums.sort()
output.write("%.2f" % percentile(nums, 0.25))
output.write("\n")
output.write("%.2f" % percentile(nums, 0.5))
output.write("\n")
output.write("%.2f" % percentile(nums, 0.75))
output.write("\n")