from random import Random
import math

def produce(n, filename):
	random = Random()
	with open(filename+".in", 'w+') as output:
		output.write(str(n)+"\n")
		for i in range(n-1):
			output.write(str(random.randint(1, 1000)) + " ")
		output.write(str(random.randint(1, 1000)) + "\n")


filename="3"
#produce(1000, filename)

input = open(filename+".in")
output = open(filename + ".out", "w+")
lines = input.readlines()
n = int(lines[0])
nums = lines[1].split()
for i in range(n - 1):
	for j in range(i, n):
		if nums[i] + nums[j] < nums[j] + nums[i]:
			nums[i], nums[j] = nums[j], nums[i]
ans = "".join(nums)
nums.reverse()
output.write(ans + " " + "".join(nums))
