from random import Random

def random_str(randomlength=8):
    str = ''
    chars = '0123456789.'
    length = len(chars) - 1
    random = Random()
    for i in range(randomlength):
        str+=chars[random.randint(0, length)]
    return str

def produce(filename):
	random = Random()
	with open(filename+".in", 'w+') as output:
		for j in range(2):
			n = random.randint(1, 10)
			for i in range(n):
				output.write(str(random.randint(1, 100))+".")
			output.write(str(random.randint(1, 100))+"\n")

def compareVersion(version1, version2):
	versions1 = [int(v) for v in version1.split(".")]
	versions2 = [int(v) for v in version2.split(".")]
	for i in range(max(len(versions1), len(version2))):
		v1 = versions1[i] if i < len(versions1) else 0
		v2 = versions2[i] if i < len(versions2) else 0
		if v1 > v2:
			return version1
		elif v2 > v1:
			return version2
	return version1


filename="4"
produce(filename)
input = open(filename+".in")
lines = input.readlines()
version1 = lines[0].strip('\n')
version2 = lines[1].strip('\n')
with open(filename+".out", 'w+') as output:
	output.write(compareVersion(version1, version2))