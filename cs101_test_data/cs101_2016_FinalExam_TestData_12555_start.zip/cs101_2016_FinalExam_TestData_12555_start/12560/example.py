n,m=[int(i) for i in input().split()]

board=[]
for i in range(n):
  board.append([int(j) for j in input().split()])
# in place solver
for i in range(n):
  for j in range(m):
    s=0
    for vi in range(i-1,i+2):
      if vi<0 or vi>=n:
        continue
      for vj in range(j-1, j+2):
        if vj<0 or vj>=m or (vi==i and vj==j):
          continue
        if board[vi][vj]&1:
          s+=1
    if board[i][j] and (s<2 or s>3):
      board[i][j]=3
    elif board[i][j]==0 and s==3:
      board[i][j]=2

for i in range(n):
  for j in range(m):
    if board[i][j]==2:
      board[i][j]=1
    elif board[i][j]==3:
      board[i][j]=0
  print(' '.join([str(k) for k in board[i]]))