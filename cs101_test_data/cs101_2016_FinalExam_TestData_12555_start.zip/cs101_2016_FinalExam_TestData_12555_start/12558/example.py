n,m=map(int,input().split())
grid=[]
for i in range(0,n):
    grid.append(list(int(i) for i in input().split()))
res=0
for i in range(0,n):
    for j in range(0,m):
        if grid[i][j] == 0:
            continue
        if i==0 or grid[i-1][j]==0:
            res+=1
        if j==0 or grid[i][j-1]==0:
            res+=1
        if i==n-1 or grid[i+1][j]==0:
            res+=1
        if j==m-1 or grid[i][j+1]==0:
            res+=1
print(res)