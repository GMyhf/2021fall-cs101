#include <iostream.h>
#include <assert.h>
#include <stdlib.h>

const int len=450*36;

int nn;
int vv[10000];
int tt[10000];

void solve(){
	cin>>nn;
	if(nn==0){
		char c;cin>>c;
		assert(cin.eof());
		exit(0);
	}
	assert(1<=nn&&nn<=10000);
	int i;
	for(i=0;i<nn;i++){
		cin>>vv[i]>>tt[i];
		assert(1<=vv[i]&&vv[i]<=40);
	}
	int min=1000000000;
	for(i=0;i<nn;i++){
		if(tt[i]<0)continue;
		int p=tt[i]+(len+vv[i]-1)/vv[i];
		if(p<min)min=p;
	}
	cout<<min<<endl;
}

int main(){
	while(1)solve();
	return 0;
}
