#include "iostream.h"
#include "string.h"
#include "stdlib.h"
#include "fstream.h"
#define N 10000

struct rider
{
	int v;
	int t;
};

int ridercmp(const void* a,const void *b)
{
	return ((rider*)a)->t-((rider*)b)->t;
}

void swap (rider &a, rider &b)
{
	rider t;
	t=a;
	a=b;
	b=t;
}
	
int main()
{
	int n,i,j;
	rider a[N];
	int arrive,temp;
	
	while(cin>>n)
	{
		if (n==0)
			break;
		for (i=0;i<n;i++)
			cin>>a[i].v>>a[i].t;

		for (i=0;i<n;i++)
			if (a[i].t<0)
			{
				swap(a[i],a[n-1]);
				n--;
				i--;
			}
			else
			{
				temp=(int)(4.5*3600)/a[i].v;				
				if (temp*a[i].v!=(int)(4.5*3600))
					temp++;
				a[i].t+=temp;
			}
		arrive=a[0].t;
		for (i=1;i<n;i++)
			if (a[i].t<arrive)
				arrive=a[i].t;
		cout<<arrive<<endl;
			
	}
	return 0;
}

