#include <iostream.h>
#include <algorithm>
#include <stdlib.h>

#define INF 0x7fffffff

int n, x, y, m, tl[1000], tr[1000];

struct platform {
	int x1, x2, h;
}p[1001];

int cmp(const void* a, const void* b) {
	return ((platform*)b)->h-((platform*)a)->h;
}

int main() {
	int t, i, j, ans;

	cin>>t;
	while (t--) {
		cin>>n>>x>>y>>m;
		for (i=0; i<n; i++)
			cin>>p[i].x1>>p[i].x2>>p[i].h;
		qsort(p, n, sizeof(platform), cmp);
		p[n].x1=-20000;  p[n].x2=20000;  p[n].h=0;
		std::fill(tl, tl+n, INF);
		std::fill(tr, tr+n, INF);
		
		// falling to platform i directly
		for (i=0; p[i].x1>x||p[i].x2<x; i++);
		if (i==n) {		// falling on the floor
			cout<<y<<endl;  continue;
		}
		tl[i]=y-p[i].h+x-p[i].x1;	// the time to leave left
		tr[i]=y-p[i].h+p[i].x2-x;	// the time to leave right
		
		ans=INF;
		for (; i<n; i++) {
			if (tl[i]==INF) continue;
			// falling from left of platform i to platform j
			x=p[i].x1;  y=p[i].h;
			for (j=i+1; y-p[j].h<=m&&(p[j].x1>x||p[j].x2<x); j++);
			if (y-p[j].h<=m) {	// safely
				if (j==n) {		// falling on the floor
					if (ans>tl[i]+y) ans=tl[i]+y;
				}
				else {
					if (tl[j]>tl[i]+y-p[j].h+x-p[j].x1)
						tl[j]=tl[i]+y-p[j].h+x-p[j].x1;
					if (tr[j]>tl[i]+y-p[j].h+p[j].x2-x)
						tr[j]=tl[i]+y-p[j].h+p[j].x2-x;
				}
			}
			// falling from right of platform i to platform j
			x=p[i].x2;
			for (j=i+1; y-p[j].h<=m&&(p[j].x1>x||p[j].x2<x); j++);
			if (y-p[j].h<=m) {	// safely
				if (j==n) {		// falling on the floor
					if (ans>tr[i]+y) ans=tr[i]+y;
				}
				else {
					if (tl[j]>tr[i]+y-p[j].h+x-p[j].x1)
						tl[j]=tr[i]+y-p[j].h+x-p[j].x1;
					if (tr[j]>tr[i]+y-p[j].h+p[j].x2-x)
						tr[j]=tr[i]+y-p[j].h+p[j].x2-x;
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}