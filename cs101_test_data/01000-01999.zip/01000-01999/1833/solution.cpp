#include<stdio.h>
#include<string.h>
#define MaxN 1101

int n,m;
int p[MaxN],f[MaxN];

void init()
{
	int i;
	
	memset(p,0,sizeof(p));
	memset(f,0,sizeof(f));
	scanf("%d %d",&n,&m);
	for (i=0; i<n; i++)
	{
		scanf("%d",p+i);
		f[p[i]]=1;
	}
}

void next()
{
	int i,j,k,l;
	
	for (i=n-1; i>=0; i--)
	{
		f[p[i]]=0;
		for (j=p[i]+1; j<=n; j++)
			if (f[j]==0)
				break;
		if (j<=n)
		{
			p[i]=j;
			f[j]=1;
			for (k=1,l=i+1; k<=n; k++)
				if (f[k]==0)
				{
					p[l++]=k;
					f[k]=1;
				}
			break;
		}
	}
	if (i<0)
	{
		for (i=1; i<=n; i++)
		{
			p[i-1]=i;
			f[i]=1;
		}
	}
}

void search()
{
	int i;
	
	for (i=0; i<m; i++)
		next();
	printf("%d",p[0]);
	for (i=1; i<n; i++)
		printf(" %d",p[i]);
	printf("\n");
}

int main()
{
	int testdata,i;

	//freopen("8.in","r",stdin);
	//freopen("out2","w",stdout);
	
	scanf("%d",&testdata);
	for (i=0; i<testdata; i++)
	{
		init();
		search();
	}
	return 0;
}