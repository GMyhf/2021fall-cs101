#include <iostream>
#include <cstring>
using namespace std;

int main()
{
    short C[301][301];
    char X[300];
    char Y[300];
    while (cin>> X >> Y) {
        short m = strlen(X), n = strlen(Y);
        short i = 0;
        for(i=0;i<=m;i++) C[i][0] = 0;
        for(i=0;i<=n;i++) C[0][i] = 0;
        for(i=1;i<=m;i++) {
            for(short j=1;j<=n;j++) {
                if (X[i-1] == Y[j-1])
                    C[i][j] = C[i-1][j-1] + 1;
                else if (C[i-1][j] >= C[i][j-1])
                    C[i][j] = C[i-1][j];
                else    C[i][j] = C[i][j-1];
            }
        }
        cout << C[m][n] << endl;
    }
}


