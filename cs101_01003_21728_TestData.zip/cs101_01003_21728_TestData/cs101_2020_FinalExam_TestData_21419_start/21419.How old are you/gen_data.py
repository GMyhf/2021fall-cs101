# import random
#
# rd = random.Random(0)
#
# for i in range(10):
#     x = rd.randint(2, 1000)
#     with open('data/' + str(i + 1) + '.in', 'w') as f:
#         f.write(str(x))
#     with open('data/' + str(i + 1) + '.out', 'w') as f:
#         lines = []
#         while x != 1:
#             if x % 2 == 0:
#                 lines.append(str(x) + '/2=' + str(int(x / 2)) + '\n')
#                 x = int(x / 2)
#             else:
#                 lines.append(str(x) + "*3+1=" + str(3 * x + 1) + '\n')
#                 x = 3 * x + 1
#
#         f.writelines(lines)

ans = []


def queen(A, cur=0):
    if cur == len(A):
        ans.append("".join([str(x + 1) for x in A]))
        return

    for col in range(len(A)):
        flag = 0
        for row in range(cur):
            if A[row] == col or abs(col - A[row]) == cur - row:
                flag = 1
        if flag == 0:
            A[cur] = col
            queen(A, cur + 1)


queen([None] * 8)
print(len(ans))
