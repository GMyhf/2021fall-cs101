x = int(input())

while x != 1:
    if x % 2 == 0:
        print(str(x) + '/2=' + str(int(x / 2)))
        x = int(x / 2)
    else:
        print(str(x) + "*3+1=" + str(3 * x + 1))
        x = 3 * x + 1