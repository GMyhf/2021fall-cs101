
# 求一个整数的所有约数，时间复杂度 O(sqrt(N))
def get_divisors(x):
    res = []
    for i in range(1, int(x**0.5) + 1):
        if x % i == 0:
            res.append(i)
            if i != x // i:
                res.append(x // i)
    res.sort()
    return res


def solve(x):
    divisors = get_divisors(x)
    print(divisors)
    res = x
    for d in divisors:
        if d > 5:
            res = x // d
            break
    return res


if __name__ == "__main__":
    sum = int(input())
    ans = solve(sum)
    print(ans)
