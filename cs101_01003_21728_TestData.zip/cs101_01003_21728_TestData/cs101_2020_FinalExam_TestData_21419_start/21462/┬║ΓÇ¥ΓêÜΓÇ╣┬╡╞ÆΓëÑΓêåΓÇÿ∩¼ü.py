n = int(input())

matrix = []
for i in range(n):
    matrix.append([int(x) for x in input().split()])

for i in range(n):
    for j in range(n):
        if matrix[i][j] == 0:
            matrix[i][j] = ''
        else:
            matrix[i][j] = chr(matrix[i][j])

record = [[0] * (n + 2) for i in range(n + 2)]
for i in range(n + 2):
    record[i][0] = 1
    record[i][n + 1] = 1
    record[0][i] = 1
    record[n + 1][i] = 1

moves = [[1, 0], [0, 1], [-1, 0], [0, -1]]
direction = 0

cur_x = 0
cur_y = 0

step = 0

ans_char = []

while step < n * n:
    step += 1

    ans_char.append(matrix[cur_x][cur_y])
    record[cur_x + 1][cur_y + 1] = 1

    if record[cur_x + moves[direction][0] + 1][cur_y + moves[direction][1] + 1] == 1:
        direction = (direction + 1) % 4

    cur_x = cur_x + moves[direction][0]
    cur_y = cur_y + moves[direction][1]

print(''.join(ans_char))