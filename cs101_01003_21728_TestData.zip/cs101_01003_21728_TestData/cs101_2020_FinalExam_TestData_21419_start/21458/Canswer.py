
T, n = [int(x) for x in input().split()]
t = []
w = []
for i in range(n):
    a, b = [int(x) for x in input().split()]
    t.append(a)
    w.append(b)

dp = [0] + [-1] * T
for i in range(n):
    for j in range(T, 0, -1):
        if j >= t[i] and dp[j - t[i]] != -1:
            dp[j] = max(dp[j], dp[j - t[i]] + w[i])

print(dp[T])
