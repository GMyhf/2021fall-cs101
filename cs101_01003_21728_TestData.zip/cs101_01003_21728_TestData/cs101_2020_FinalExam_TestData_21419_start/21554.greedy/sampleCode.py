# -*- coding: utf-8 -*-
"""
Created on Sat Dec 5 15:33:05 2020

@author: huyang
"""

n = int(input())
t = [int(x) for x in input().split()]
idxs = sorted(range(1,n+1), key=lambda x: t[x-1])
print(' '.join([str(x) for x in idxs]))

t.sort()  # ascending

waiting_time = 0.0
cur_waiting_time = 0.0
for i, ti in enumerate(t):
	if i == n-1:
		continue
	cur_waiting_time += ti
	waiting_time += cur_waiting_time

waiting_time /= float(n)
print('%.2f' % waiting_time)