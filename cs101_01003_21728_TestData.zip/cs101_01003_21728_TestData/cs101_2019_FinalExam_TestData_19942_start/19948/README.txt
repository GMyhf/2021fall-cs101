# 题目说明

时限：1 s

算法：greedy, sortings

难度：稍难