// F(n,m)=F(n-1,m-1)+m*F(n-1,m)
#include <iostream>

int a[16][16];
using namespace std;

int f(int,int);

int main()
{
    memset(a,0,sizeof(a));
    for (int i=0; i<16; i++){
        for (int j=0; j<16; j++) {
            if (j>i) break;
            a[i][j] = f(i,j);
        }
    }

    //int n,m;
    int n;
    while (cin >> n) {
        //cout << f(n,m) << endl;
        int sum=0;
        if (n==0 ) {
            cout << "1\n";
            continue;
        }

        for (int i=1; i<=n; i++)
            sum += a[n][i];

        cout << sum << endl;
    }
}

int f(int n, int m)
{
    if ( n==0 || n==m || n==1 || m==1)
        return 1;
    if ( n<m )
        return 0;

    if (a[n-1][m-1] && a[n-1][m])
        return a[n-1][m-1] + m*a[n-1][m];
    if (a[n-1][m-1])
        return a[n-1][m-1] + m*f(n-1,m);
    if (a[n-1][m])
        return f(n-1,m-1) + m*a[n-1][m];

    return f(n-1,m-1) + m*f(n-1,m);
}
