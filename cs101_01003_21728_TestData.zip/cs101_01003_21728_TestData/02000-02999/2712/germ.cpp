#include <stdio.h>

void main()
{
	int k,m;
	int month[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
	int bm, bd, em, ed, init, days, total, i;

	scanf("%d", &k);

	for( m=0; m<k; m++)
	{
		scanf("%d %d %d %d %d", &bm, &bd, &init, &em, &ed);

		total = init;
		if( bm==em )  days = ed - bd;
		else
		{
			days = month[bm-1] - bd;
			for(i=(bm+1); i<em; i++)
			{
				days += month[i-1];
			}
			days += ed;
		}

		for(i=0;i<days;i++)
		{
			total *= 2;
		}

		printf("%d\n", total);
	}
}
