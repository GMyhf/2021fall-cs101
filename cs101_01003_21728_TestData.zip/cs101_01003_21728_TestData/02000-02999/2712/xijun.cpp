// task1.cpp : Defines the entry point for the console application.
//

#include <stdio.h>
int month[12]={31,28,31,30,31,30,31,31,30,31,30,31};

void main()
{
	 int n;
     int i;
	 scanf("%d",&n);
	 while(n--){
		 int s1,s2,no,e1,e2;
		 scanf("%d%d%d%d%d",&s1,&s2,&no,&e1,&e2);
         int days=0;
		 if(s1==e1) days = e2-s2;
		 else{
			 days = month[s1-1]-s2;
		    for(i=s1+1;i<e1;i++)
				days += month[i-1];
			days += e2;
		 }
		 long amount=no;
         for(i=0;i<days;i++) amount *= 2;
		 printf("%ld\n",amount);
		 
	 }

}
