#include<fstream.h>
#include<stdlib.h>
#include<string.h>
ifstream in;
ifstream ou;
ifstream aws;
int p[200],d[200],n,m,i,lena,lenu,j,last,curr,pa,da,pt,dt;
char linea[255],lineu[255];
void checkstring(int t)
{
	for(i=0;i<t;i++){
		ou>>linea;
		aws>>lineu;
		if(!ou)exit(1);
		if(strcmp(linea,lineu))exit(1);
	}
}
void CheckHead()
{
	checkstring(6);
	aws>>pa;
	ou>>pt;
	if(!ou)exit(1);
	if(pa!=pt)exit(1);
	checkstring(4);
	aws>>da;
	ou>>dt;
	if(!ou)exit(1);
	if(da!=dt)exit(1);
	checkstring(2);
}
int main(int argc,char* argv[])
{
	in.open(argv[1]);
	ou.open(argv[2]);
	aws.open(argv[3]);
	in>>n>>m;
	while(n!=0){
		for(i=0;i<n;i++)
			in>>p[i]>>d[i];
		CheckHead();
		pt=dt=0;last=0;
		for(i=0;i<m;i++)
		{
			aws>>curr;
			ou>>curr;
			if(!ou)return 1;
			if(curr<1||curr>n||curr<=last)return 1;
			last=curr;
			pt+=p[curr-1];
			dt+=d[curr-1];
		}
		if(pt!=pa||dt!=da)return 1;
		in>>n>>m;
	}
	return 0;
}