// task3.cpp : Defines the entry point for the console application.
//


#include <stdio.h>

void main()
{
	int n,i,age;
	double sum=0;
    scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&age);
		sum += age;
	}
	printf("%.2lf",sum/n);
}


