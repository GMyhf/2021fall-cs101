// sort.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
int main(int argc, char* argv[])
{
	int n,i,j;
	struct rat{
		int weight;
		char color[11];
	}rats[101],tmp;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d %s",&(rats[i].weight),rats[i].color);
    for(i=n-1;i>0;i--)
	for(j=0;j<i;j++){
			if(rats[j].weight<rats[j+1].weight){
				tmp = rats[j];
				rats[j] = rats[j+1];
				rats[j+1] = tmp;
			}
	}
	for(i=0;i<n;i++)
	     printf("%s\n",rats[i].color);
	return 0;
}

