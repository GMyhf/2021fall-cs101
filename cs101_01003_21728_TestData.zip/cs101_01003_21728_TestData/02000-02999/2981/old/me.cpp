#include <iostream>
#include <string>
using namespace std;
int main()
{     string str1,str2;
    getline(cin,str1);//输入两个字符串；
    getline(cin,str2);
    int max=str1.size();//求出最大的字符串的长度，以便定义int数组；
    if (str1.size()<str2.size())
        max=str2.size();

    int a[max],b[max],c[max+1];//定义三个int数组；
    for (int i=0;i<max;i++){//给三个数组赋值；
        a[i]=0;b[i]=0;
    }
    for (int i=0;i<=max;i++)
        c[i]=0;

    for (int i=max-1;i>=max-str1.size();i--)//把输入的数字字符转化成整型，并存到数组中；
        a[i]=(int)(str1[i])-(int)('0');

    for (int i=max-1;i>=max-str2.size();i--)
        b[i]=(int)(str2[i])-(int)('0');

    for(int i=0;i<max;i++){              //把两个整型数组对应的元素相加，并存到数组c中；
        c[i+1]=a[i]+b[i];
    }

    for(int i=max;i>0;i--){             //判断数组的每一个元素，若大于九就进行调整；
        if(c[i]>9)
            c[i-1]+=1;
        c[i]-=10;
    }
    if(c[0]==0){                       //判断第一个元素是不是0并输出数组c；
        for (int i=1;i<=max;i++)
            cout << c[i];
        cout << endl;}
    else {
        for (int i=0;i<=max;i++)
            cout << c[i];cout << endl;}
}
