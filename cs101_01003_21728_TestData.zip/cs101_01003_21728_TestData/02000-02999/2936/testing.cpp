// testing.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
int main(int argc, char* argv[])
{
	int n,tmp,i,number[9];
	for(i=0;i<9;i++) number[i]=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&tmp);
		number[tmp]=1;
	}
	if(number[1] == number[2] && number[2]==1) 
		printf("0");
	else if (number[3] == number[4] && number[4]==1)
		printf("0");
	else if(number[5] != number[6])
		printf("0");
	else if(number[7]==0 && number[8]==0)
		printf("0");
	else
		printf("1");
	return 0;
}

