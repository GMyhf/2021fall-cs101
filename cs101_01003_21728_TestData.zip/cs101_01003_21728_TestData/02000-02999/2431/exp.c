/*
PROB: exp
LANG: C
*/
#include <stdio.h>
#include <stdlib.h>

#define MAX_N 10000
#define MAX_D 1000000
#define MAX_F 100

typedef struct {
  int D, F;
} Store;

Store S[MAX_N];
int N, D_truck, F_truck;
int count[MAX_F+1];

static int Scomp(const void *p1, const void *p2)
{
  Store *s1 = (Store *)p1;
  Store *s2 = (Store *)p2;

  return s1->D - s2->D;
}

int main(void) 
{
  FILE *fp;
  int i, visits = 0;

  fp = fopen ("exp.in", "r");
  fscanf (fp, "%d", &N);
  for(i=0; i<N; i++)
    fscanf (fp, "%d %d", &S[i].D, &S[i].F);
  fscanf (fp, "%d %d", &D_truck, &F_truck);
  fclose (fp);

  qsort(S, N, sizeof(Store), Scomp);

  while (1) {
    
    /* More forward as far as possible */
    D_truck -= F_truck;
    F_truck = 0;
    while (N >= 1 && S[N-1].D >= D_truck) {
      count[S[N-1].F]++;
      N--;
    }

    /* If we've reached the town, great! */
    if (D_truck <= 0) break;

    /* Otherwise, "retroactively" grab the best fuel store en route
       so far */
    i = MAX_F;
    while (count[i] == 0) {
      i--;
      if (i==0) { visits=-1; goto fail; }
    }
    
    F_truck += i;
    count[i]--;
    visits++;
  }

 fail:
  fp = fopen ("exp.out", "w");
  fprintf (fp, "%d\n", visits);
  fclose (fp);
  
}
