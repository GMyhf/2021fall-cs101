import random
import sys
import os

# if len(sys.argv) != 2:
#     print("Usage: produceCase.py caseNum\n无输入程序将使用使用默认case数量20")
#     caseNum = 20
# else:
#     caseNum = int(sys.argc[1])


caseNum = 20
R = random.randint
S = random.shuffle
for i in range(caseNum):
    with open(str(i+1) + ".in", "w") as fout:
        m = R(1, 100)
        print(m, file=fout)
        for line in range(m):
            if R(1, 100) > 30:
                if R(1, 100) > 50:
                    data = [R(1, int(10)) for num in range(4)]
                else:
                    data = [R(1, int(10)) for num in range(3)]
                    data = data + [24-sum(data)]
            else:
                a = R(1, int(10e100))if R(1,10) < 6 else -R(1, int(10e100))
                b = R(1, int(10e100))if R(1,10) < 6 else -R(1, int(10e100))
                c = R(1, int(10e100))if R(1,10) < 6 else -R(1, int(10e100))
                d = 24-a-b-c
                data = [a, b, c, d]
            data = [str(abs(num)) for num in data]
            print(' '.join(data), file=fout)

    os.system("python sampleCode.py < %d.in > %d.out" %(i+1, i+1))