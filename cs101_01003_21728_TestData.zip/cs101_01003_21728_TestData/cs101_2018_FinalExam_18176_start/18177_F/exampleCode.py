import math
mean = lambda l: float(sum(l)) / len(l)

def std(l):
    m = mean(l)
    return math.sqrt(sum((i-m)**2 for i in l)/len(l))

def Pair(A,B):
    Days = len(A)
    profit = 0
    historicalDiff = []
    historicalDiff.append(A[0]-B[0])
    historicalDiff.append(A[1]-B[1])
    historicalDiff.append(A[2]-B[2])
    for i in range(3,Days-1):
        Std, Mean = std(historicalDiff), mean(historicalDiff)
        currentDiff = A[i]-B[i]
        normal = (currentDiff - Mean)/Std
        position = [-int(normal),int(normal)]
        todayProfitA = (A[i+1]-A[i]) * position[0]
        todayProfitB = (B[i+1]-B[i]) * position[1]
        profit+= (todayProfitA+todayProfitB)
        historicalDiff.append(currentDiff)
    return profit

m, n = [int(i) for i in input().split()]
data = []
for i in range(m):
    data.append([int(i) for i in input().split()])

ans = -1e60
ii, jj = -1, -1
for i in range(m-1):
    for j in range(i+1, m):
        if Pair(data[i], data[j]) > ans:
            ii, jj = i, j
            ans = Pair(data[i], data[j])

print(ii + 1, jj + 1, ans)
