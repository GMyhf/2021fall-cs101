import random


def imageSmoother(M):
    R, C = len(M), len(M[0])
    res = [[0] * C for _ in M]
    for r in range(R):
        for c in range(C):
            count = 0
            for nr in (r - 1, r, r + 1):
                for nc in (c - 1, c, c + 1):
                    if 0 <= nr < R and 0 <= nc < C:
                        res[r][c] += M[nr][nc]
                        count += 1
            res[r][c] = int(res[r][c]/count)
    return res

def generateM(m,n):
    res = [ [0] * n for _ in range(m)]
    for r in range(m):
        for c in range(n):
            res[r][c] = str(random.randint(1,6))
    return res


def transformStr2Int(M):
    R, C = len(M), len(M[0])
    for r in range(R):
        for c in range(C):
            M[r][c] = int(M[r][c])
    return M

def transformInt2Str(M):
    R, C = len(M), len(M[0])
    for r in range(R):
        for c in range(C):
            M[r][c] = str(M[r][c])
    return M


if __name__ == '__main__':
    t = 15
    for i in range(t):
        r = random.randint(6,10)
        c = random.randint(6,10)
        M = generateM(r,c)
        print(M)
        with open("{}.in".format(i+1),"w") as f:
            f.write(str(r)+" "+str(c))
            f.write("\n")
            for row in range(r):
                f.write(" ".join(M[row]))
                if row != r - 1:
                    f.write("\n")
        M = transformStr2Int(M)
        res = imageSmoother(M)
        res = transformInt2Str(res)
        print(res)
        with open("{}.out".format(i+1),"w") as f:
            # f.write()
            for row in range(r):
                f.write(" ".join(res[row]))
                if row != r - 1:
                    f.write("\n")
