R, C = input().split()
R, C = int(R), int(C)
M = []
for i in range(R):
    tmp = []
    row = input().split()
    for j in range(C):
        tmp.append(int(row[j]))
    M.append(tmp)


def imageSmoother(M):
    R, C = len(M), len(M[0])
    res = [[0] * C for _ in M]
    for r in range(R):
        for c in range(C):
            count = 0
            for nr in (r - 1, r, r + 1):
                for nc in (c - 1, c, c + 1):
                    if 0 <= nr < R and 0 <= nc < C:
                        res[r][c] += M[nr][nc]
                        count += 1
            res[r][c] = int(res[r][c]/count)
    return res


M = imageSmoother(M)

for i in range(R):
    for j in range(C):
        if j != C-1:
            print(M[i][j], end=" ")
        else:
            print(M[i][j])