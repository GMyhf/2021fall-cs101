l = []
i = 1
while i*i < 1000:
	l.append(i*i)
	i += 1

magics = []
for i in l:
	for j in l:
		magics.append(i+j)


m = int(input())
x = [int(i) for i in input().split()]

for num in x:
	if num in magics:
		print(bin(num), oct(num), hex(num))

