A,B,C = [],[],[]

[a,b] = list(map(int, input().split()))
for i in range(a):
    A.append(list(map(int, input().split())))

[c,d] = list(map(int, input().split()))
for i in range(c):
    B.append(list(map(int, input().split())))

[e,f] = list(map(int, input().split()))
for i in range(e):
    C.append(list(map(int, input().split())))

if b!=c or a!=e or d!=f:
    print("Error!")
else:
    D = [[0 for j in range(f)] for i in range(e)]
    for i in range(e):
        for j in range(f):
            for k in range(b):
                D[i][j] += A[i][k] * B [k][j]
            D[i][j] += C[i][j]

    for i in range(e):
        print(' '.join([str(j) for j in D[i]]))