N = int(input())
for i in range(N):
    s = input()
    n = len(s)
    period = n
    for k in range(1, n):
        j = k
        while j < n and s[j] == s[j % k]:
            j += 1
        if j == n and j % k == 0:
            period = k
            break
    print(period)
