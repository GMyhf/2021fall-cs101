# OJ18159
CELL_INT=10001

def init(prime,mark,CELL):
	for i in range(CELL):
		mark.append(1)
	for j in range(2,CELL):
		if(mark[j]==0):
			continue
		prime.append(j)
		k=j*j
		while(k<CELL):
			#no prime
			mark[k]=0
			k+=j

prime=[]
mark=[]


T = int(input())

init(prime,mark,CELL_INT)
for row in range(1,T+1):
    print("Case"+str(row)+":")
    flag=0
    first=0
    limit=int(input())
    for i in range(len(prime)):
        if(prime[i]<limit and prime[i]%10==1):
            flag=1
            if(first==0):
                print(str(prime[i]), end='')
                first = 1
            else:
                print(" " + str(prime[i]), end=''),
    
    if(flag==0):
        print("NULL")
    else:
        print("")
