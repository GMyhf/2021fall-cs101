from random import Random
import math

CELL_INT=10000

def init(prime,mark,CELL):
	for i in range(CELL):
		mark.append(1)
	for j in range(2,CELL):
		if(mark[j]==0):
			continue
		prime.append(j)
		k=j*j
		while(k<CELL):
			#no prime
			mark[k]=0
			k+=j


def produce(filename,case_num):
	with open(filename+".in", 'w+') as output:
		random = Random()
		T=case_num
		output.write(str(T)+"\n")
		while(T):
			T-=1
			start = random.randint(2, CELL_INT)
			output.write(str(start)+"\n")


prime=[]
mark=[]

#filename,total test_case
filename="6"
test_case=1500
produce(filename,test_case)

input = open(filename+".in")
output = open(filename + ".out", "w+")
lines = input.readlines()
T = int(lines[0])

init(prime,mark,CELL_INT)
for row in range(1,T+1):
	output.write("Case"+str(row)+":\n")
	flag=0
	first=0
	limit=int(lines[row])
	for i in range(len(prime)):
		if(prime[i]<limit and prime[i]%10==1):
			flag=1
			if(first==0):
				first=1
				output.write(str(prime[i]))
			else:
				output.write(" "+str(prime[i]))
	if(flag==0):
		output.write("NULL"+"\n")
	else:
		output.write("\n")

