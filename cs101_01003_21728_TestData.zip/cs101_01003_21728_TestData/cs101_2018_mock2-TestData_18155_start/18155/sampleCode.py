T = int(input())

data = input()
S = [int(ele) for ele in data.split()]


def DFS(S, T, cur_state, is_null, cur_pos):
    if is_null == False and cur_state == T:
        return True

    if cur_pos == len(S):
        return False

    if DFS(S, T, cur_state * S[cur_pos], False, cur_pos + 1):
        return True

    if DFS(S, T, cur_state, is_null, cur_pos + 1):
        return True

    return False


if DFS(S, T, 1, True, 0):
    print("YES")
else:
    print("NO")