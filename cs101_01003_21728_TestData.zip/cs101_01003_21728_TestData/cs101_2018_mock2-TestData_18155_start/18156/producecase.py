def solve(S, T):

    S.sort()

    i = 0
    j = len(S) - 1

    res = S[i] + S[j]
    while i < j:

        cur_val = S[i] + S[j]

        if abs(cur_val - T) < abs(res - T):
            res = cur_val

        if abs(cur_val - T) == abs(res - T) and cur_val < res:
            res = cur_val

        if cur_val == T:
            break
        elif cur_val < T:
            i = i + 1
        else:
            j = j - 1

    return res

def brute_solve(S, T):

    res = S[0] + S[1]
    for i in range(0, len(S)):
        for j in range(i+1, len(S)):

            cur_val = S[i] + S[j]

            if abs(cur_val - T) < abs(res - T):
                res = cur_val

            if abs(cur_val - T) == abs(res - T) and cur_val < res:
                res = cur_val

    return res

from random import randint

for case_id in range(1, 51):

    print("current case id: " + str(case_id) + "\n")

    if case_id <= 25:
        N = randint(2, 1000)
    else:
        N = randint(2, 100000)
    print("N = " + str(N) + "\n")

    S = list()
    for i in range(0, N):
        S.append(randint(0, 65535))

    T = randint(0, 65535*2)
    print("T = " + str(T) + "\n")

    S_copy = S[:]
    res = solve(S_copy, T)

    # brute_res = brute_solve(S, T)
    # if res != brute_res:
    #     print("Error in produce case!")

    fin = open(str(case_id) + ".in", "w")
    fin.write(str(T) + "\n")
    for ele in S:
        fin.write(str(ele) + " ")

    fout = open(str(case_id) + ".out", "w")
    fout.write(str(res))

