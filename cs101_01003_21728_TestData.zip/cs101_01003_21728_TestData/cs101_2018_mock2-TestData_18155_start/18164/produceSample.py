import os
import random
caseNumber = 10
for i in range(caseNumber):
    with open(str(i+1)+".in", "w") as f:
        N = int(random.randint(1, 20000))
        print(N, file=f)
        num = " ".join(random.sample([str(x) for x in range(0, 50000)], N))
        print(num, file=f)
    os.system("python3 sampleCode.py <%d.in> %d.out" %(i+1, i+1))
