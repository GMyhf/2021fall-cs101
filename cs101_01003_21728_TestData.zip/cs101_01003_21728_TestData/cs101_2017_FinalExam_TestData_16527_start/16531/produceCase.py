import random
import sys
import os

# if len(sys.argv) != 2:
#     print("Usage: produceCase.py caseNum\n无输入程序将使用使用默认case数量20")
#     caseNum = 20
# else:
#     caseNum = int(sys.argc[1])

caseNum = 20

for i in range(caseNum):
    with open(str(i+1) + ".in", "w") as fout:
        m = int(random.randint(1, 20))
        n = int(random.randint(1, 20))
        print(m, n, file=fout)
        order = list(range(m*n))
        random.shuffle(order)
        for j in range(m*n):
            print(order[j], file=fout, end=' ')
            if (j+1) % n == 0:
                print(file=fout)
        qNums = random.randint(0, 10)
        for j in range(m*n):
            for k in range(qNums):
                print(random.randint(0, 1), file=fout, end=' ')
            print(file=fout)

    os.system("python sampleCode.py < %d.in > %d.out" %(i+1, i+1))


