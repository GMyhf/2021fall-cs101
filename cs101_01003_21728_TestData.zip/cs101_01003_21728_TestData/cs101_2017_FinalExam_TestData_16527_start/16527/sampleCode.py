str_A = input()
str_B = input()

for i in range(0, len(str_A))[::-1]:
    if str_B.startswith(str_A[i:]):
        print(i)
        exit()