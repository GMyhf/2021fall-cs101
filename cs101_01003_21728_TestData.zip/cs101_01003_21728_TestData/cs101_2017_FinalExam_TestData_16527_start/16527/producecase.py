f = open("1.in", "w")
f.write("xxxxxabc\n")
f.write("abc********")
f.close()

f = open("1.out", "w")
f.write("5")
f.close()

##################################################################

f = open("2.in", "w")
f.write("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\n")
f.write("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
f.close()

f = open("2.out", "w")
f.write("32")
f.close()

##################################################################

f = open("3.in", "w")
f.write("aaaaaaaaaaaaaaaabaaaaaaaaaaaaaaaaa\n")
f.write("baaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
f.close()

f = open("3.out", "w")
f.write("16")
f.close()

##################################################################

f = open("4.in", "w")
f.write("sfdsfdsdfsfdsafjlgfoerotoeirutoljlkclgjlskfsksskjhfksjghikwheurisdfhskdfhksjdfhiwuertfhksjdfksdjhfcfsjmfgjlsfoeiiiosdkfjklsajfjsfhjkhjknjlsdfjlsfksjlfddg\n")
f.write("jklsajfjsfhjkhjknjlsdfjlsfksjlfddgbaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
f.close()

f = open("4.out", "w")
f.write("119")
f.close()

##################################################################

f = open("5.in", "w")
f.write("sfdsfdsdfsfdsafjlgfoerotoeirutoljlkclgjlskfsksskjhfkuosjghikwsdfuioeuwrtldkjfglmsasfisenrfddsnfsjkdfheurisdfhskdfhksjioudfhiwuertfhksjdfksdjhfcfsjmfgjlsfoeiiiosdkfjklsajfjsfhjkhjknjlsdfjlsfksjlfddg\n")
f.write("jknjlsdfjlsfksjlfddgjklsajfjsfhjkhjknjlsdfjlsfksjlfddgbaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
f.close()

f = open("5.out", "w")
f.write("177")
f.close()

##################################################################

f = open("6.in", "w")
f.write("sfdsfdsdfsfdsafjlgfoerotoeirutoljlksfdsdgdfgsjfpoiposdkfksdfkasdfljclgjlskfsksskjhfkuosjghikwsdfuioeuwrtldkjfglmsasfisenrfddsnfsjkdfheurisdfhskdfhksjioudfhiwuertfhksjdfksdjhfcfsjmfgjlsfoeiiiosdkfjklsajfjsfhjkhjknjlsdfjlsfksjlfddg\n")
f.write("sdfjlsfksjlfddgjknjlsdfjlsfksjlfddgjklsajfjsfhjkhjknjlsdfjlsfksjlfddgbaaaaadgdfgasfsfasdfsfaaaaaaaaaadfgdfgsdfgdgfdfgaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
f.close()

f = open("6.out", "w")
f.write("214")
f.close()