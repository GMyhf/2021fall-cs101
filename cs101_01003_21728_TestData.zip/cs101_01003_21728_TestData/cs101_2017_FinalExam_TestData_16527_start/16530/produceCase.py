import random
import string
import os
caseNumber = 10
for i in range(caseNumber):
    with open(str(i+1) + ".in", "w") as f:
        n = random.sample([x for x in range(2, 1001) if x % 2 == 0], 1)[0]
        print(n, file=f)
        for j in range(n):
            l = random.randint(1, 26)
            name = "".join(random.sample(string.ascii_uppercase, l))
            print(name, file=f)
    os.system("python3 sampleCode.py <%d.in> %d.out" %(i+1,i+1))
