#include<iostream>
#include<cmath>
using namespace std;
int main()
{
    int a[6];
    while(cin>>a[0]>>a[1]>>a[2]>>a[3]>>a[4]>>a[5]){
        if(a[0]==0&&a[1]==0&&a[2]==0&&a[3]==0&&a[4]==0&&a[5]==0) break;


    }
}
