import java.io.*;
import java.util.*;

public class houseboat {
  public static void main (String[] argv) throws Exception {
    BufferedReader input =
      new BufferedReader(new InputStreamReader(System.in));
    

    int N = Integer.parseInt(input.readLine().trim());

    for(int n = 1;n<N+1;n++){
      StringTokenizer tk = new StringTokenizer(input.readLine());
      double x = Double.parseDouble(tk.nextToken());
      double y = Double.parseDouble(tk.nextToken());
      
      double dist = Math.sqrt(x*x+y*y);

      // circle area is pi*r^2
      // semicircle area is pi*r^2 / 2
      // 50*y = pi*r^2 / 2
      // y = pi * r ^ 2 / 100
      
      int year = (int) (Math.PI * (dist*dist) / 100.0);
      year += 1;

      System.out.println("Property "+n+
			 ": This property will begin eroding in year "+year+
			 ".");
    }

    System.out.println("END OF OUTPUT.");
  }
}

      
