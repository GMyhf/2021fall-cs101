#include <iostream.h>

int main() {
	int i, t, a, b, c, d;
	char x1, y1, x2, y2;

	cin>>t;
	for (i=0; i<t; i++) {
		cin>>x1>>y1>>x2>>y2;
		x1-='a';  y1-='1';  x2-='a';  y2-='1';
		if (x1==x2&&y1==y2) {
			cout<<"0 0 0 0"<<endl;
			continue;
		}
		// king
		a=x2>x1?x2-x1:x1-x2;
		b=y2>y1?y2-y1:y1-y2;
		if (a>b)
			cout<<a<<' ';
		else
			cout<<b<<' ';
		// queen
		if (x1==x2||y1==y2||x1-x2==y1-y2||x1+x2==y1+y2)
			cout<<"1 ";
		else
			cout<<"2 ";
		// bishop
		if (x1-x2==y1-y2||x1+x2==y1+y2)
			cout<<"1 ";
		else {
			a=x1+y1+x2-y2;  b=x1+y1-x2+y2;
			c=x2+y2+x1-y1;  d=x2+y2-x1+y1;
			if ((a%2||a<0||a>=16||b%2||b<0||b>=16)
				&&(c%2||c<0||c>=16||d%2||d<0||d>=16))
				cout<<"Inf ";
			else
				cout<<"2 ";
		}
		// rook
		if (x1==x2||y1==y2)
			cout<<"1"<<endl;
		else
			cout<<"2"<<endl;
	}
	return 0;
}