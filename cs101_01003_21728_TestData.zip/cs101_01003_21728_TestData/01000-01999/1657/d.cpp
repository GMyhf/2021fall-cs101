////////////////////////////////////////////////////
// problem D -- Distance on Chessboard
// Author : Epic
// Email  : shishi@db.pku.edu.cn
// Algorithm : Simulation
#include <iostream.h>
#include <stdlib.h>
#define max(x, y) ( (x)>(y) ? (x) : (y) )
int main() {
	int icase, ncase;
	int x1, y1, x2, y2, dx, dy;
	char pos1[4], pos2[4];
	cin>>ncase;
	for ( icase=0; icase<ncase; icase++) {
		cin>>pos1>>pos2;
		x1 = pos1[0] - 'a';
		y1 = pos1[1] - '1';
		x2 = pos2[0] - 'a';
		y2 = pos2[1] - '1';
		dx = abs(x1 - x2);
		dy = abs(y1 - y2);
		cout<<max(dx, dy)<<' ';
		if ( !dx && !dy ) cout<<"0 ";
		else if ( dx==dy || !dx || !dy ) cout<<"1 ";
		else cout<<"2 ";
		if ( !dx && !dy ) cout<<"0 ";
		else if ( dx==dy ) cout<<"1 ";
		else if ( (dx-dy)%2 ) cout<<"Inf ";
		else cout<<"2 ";
		cout<<bool(dx)+bool(dy)<<endl;
	}
	return 0;
}
