#include<fstream.h>
#include<string.h>
#define N 1000
int main(int argc,char * argv[])
{
    ifstream oi(argv[1]);
	ifstream ou(argv[2]);
	ifstream oa(argv[3]);
	int i,j,st,r;
	char c,b[9],s[N];

	oa.getline(s,N);
	if(strcmp(s,"unsolvable")==0)
	{
        i=0;r=0;
        if(!ou.getline(s,N))return 1;
        for(i=strlen(s)-1;i>=0&&s[i]==' ';i--);
        s[i+1]=0;
        for(i=0;s[i]==' ';i++);
        if(strcmp(&s[i],"unsolvable"))
            return 1;
        if(ou>>c)return 1;
        else return 0;
	}
	for(i=0;i<9;i++)
	{
		oi>>b[i];
		if(b[i]=='x')st=i;
	}
	if(!ou.getline(s,N))
	{
		if(s[0])ou.clear();
		else return 1;
	}
    i=0;j=0;
    while(1)
    {
        if(s[i]==0)
        {
			if(!ou.getline(s,N))
			{
				if(s[0])ou.clear();
				else break;
			}
			i=0;
        }
        switch(s[i])
        {
        case 'd':if(st>=6)
					 return 1;
                b[st]=b[st+3];b[st+3]='x';
                st+=3;j++;
                break;
        case 'u':if(st<3)
					 return 1;
                b[st]=b[st-3];b[st-3]='x';
                st-=3;j++;
                break;
        case 'r':if(st%3==2)
					 return 1;
                b[st]=b[st+1];b[st+1]='x';
                st++;j++;
                break;
        case 'l':if(st%3==0)
					 return 1;
                b[st]=b[st-1];b[st-1]='x';
                st--;j++;
                break;
        default:if(s[i]>32)
					return 1;
                break;
        }
        i++;
    }
    if(st!=8)
		return 1;
    for(i=0;i<8;i++)
        if(b[i]!='1'+i)
			return 1;
	return 0;
}
