#include <iostream.h> 
#define BITS_PER_WORD (8*sizeof(unsigned)) 
#define ROW_SIZE 3 
#define PERM_SIZE (ROW_SIZE*ROW_SIZE) 

template <class T> 
inline void swap (T& a,  T& b) 
{ T t = a; a = b; b = t; } 

void itop(unsigned perm[], unsigned n) 
{ 
  perm[0] = 0; 
  for (unsigned i = 1; i < PERM_SIZE; ++i) 
    { 
      unsigned p = i - n % (i+1); 
      perm[i] = perm[p]; 
      perm[p] = i; 
      n /= i+1; 
    } 
} 

unsigned ptoi(unsigned const perm[]) 
{ 
  unsigned n = 0; 
  unsigned i, pcpy[PERM_SIZE], invp[PERM_SIZE]; 

  for (i = 0; i < PERM_SIZE; ++i) 
    { 
      pcpy[i] = perm[i]; 
      invp[perm[i]] = i; 
    } 

  for (i = PERM_SIZE-1; i > 0; --i) 
    { 
      unsigned p = invp[i]; 
      pcpy[p] = pcpy[i]; 
      pcpy[i] = i; 
      invp[pcpy[p]] = p; 
      invp[i] = i; 
      n *= i+1; 
      n += i - p; 
    } 

  return n; 
} 

struct Arrangement 
{ 
  unsigned permCode; 
  unsigned parent; 
}; 

void addToQueue(unsigned parent, unsigned perm[], 
                unsigned bitset[], 
                Arrangement permBuffer[], unsigned& last) 
{ 
  unsigned code = ptoi(perm); 
  unsigned m = code/BITS_PER_WORD; 
  unsigned n = code%BITS_PER_WORD; 
  if ( (bitset[m] >> n) & 1) 
    return; 

  bitset[m] |= 1 << n; 
  permBuffer[last].parent = parent; 
  permBuffer[last++].permCode = code; 
} 

int main() 
{ 
  unsigned initperm[PERM_SIZE]; 
  unsigned factorial = 1; 
  unsigned i; 
  for (i = 0; i < PERM_SIZE; ++i) 
    { 
      //cin >> n;
	  char ch;
	  cin>>ch;
	  if(ch!='x')initperm[i]=ch-'1';
	  else initperm[i]=PERM_SIZE-1;

      factorial *= i+1; 
    } 

  unsigned initcode = ptoi(initperm); 

  unsigned maskSize = (factorial + BITS_PER_WORD - 1) / BITS_PER_WORD; 
  unsigned* bitset = new unsigned[maskSize]; 
  for (i = 0; i < maskSize; ++i) 
    bitset[i] = 0; 

  bitset[initcode/BITS_PER_WORD] |= 1 << (initcode % BITS_PER_WORD); 

  unsigned first = 0; 
  unsigned last = 0; 
  Arrangement* permBuffer = new Arrangement [factorial/2]; 
  permBuffer[last].parent = -1; 
  permBuffer[last++].permCode = initcode; 
  

  unsigned code; 
  while ((code = permBuffer[first].permCode) > 1 && 
         first < factorial/2) 
    { 
      unsigned perm[PERM_SIZE]; 
      itop(perm, code); 

      // find the blank 
      unsigned i; 
      for (i = 0; perm[i] != PERM_SIZE-1 && i < PERM_SIZE; ++i) 
        {} 

      unsigned blank_row = i / ROW_SIZE; 
      unsigned blank_col = i % ROW_SIZE; 

      if (blank_row > 0) 
        { 
          swap (perm[i], perm[i-ROW_SIZE]); 
          addToQueue(first, perm, bitset, permBuffer, last); 
          swap (perm[i], perm[i-ROW_SIZE]); 
        } 

      if (blank_row < ROW_SIZE-1) 
        { 
          swap (perm[i], perm[i+ROW_SIZE]); 
          addToQueue(first, perm, bitset, permBuffer, last); 
          swap (perm[i], perm[i+ROW_SIZE]); 
        } 

      if (blank_col > 0) 
        { 
          swap (perm[i], perm[i-1]); 
          addToQueue(first, perm, bitset, permBuffer, last); 
          swap (perm[i], perm[i-1]); 
        } 

      if (blank_col < ROW_SIZE-1) 
        { 
          swap (perm[i], perm[i+1]); 
          addToQueue(first, perm, bitset, permBuffer, last); 
          swap (perm[i], perm[i+1]); 
        } 
      ++first; 
    } 

  if (permBuffer[first].permCode == 1) 
    { 
      cout << "unsolvable\n"; 
      return 0; 
    } 

  char revpath[1000]; 
  unsigned nextChar = 0; 

  unsigned p; 
  unsigned* perm = new unsigned[PERM_SIZE]; 
  itop(perm, permBuffer[first].permCode); 
  unsigned blank; 
  for (blank = 0; perm[blank] != PERM_SIZE-1; ++blank) 
    {} 

  unsigned* par_perm = new unsigned[PERM_SIZE]; 
  while ((p = permBuffer[first].parent) != -1) 
    { 
      itop(par_perm, permBuffer[p].permCode); 

      unsigned par_blank; 
      for (par_blank = 0; par_perm[par_blank] != PERM_SIZE-1; ++par_blank) 
        {} 

      char c; 
      if (par_blank > blank) 
        if (par_blank ==  blank + ROW_SIZE) 
          c = 'u'; 
        else 
          c = 'l'; 
      else 
        if (par_blank == blank - ROW_SIZE) 
          c = 'd'; 
        else 
          c = 'r'; 

      revpath[nextChar++] = c; 

      swap(perm, par_perm); 
      blank = par_blank; 
      first = p; 
    } 

  while (nextChar--) 
    cout << revpath[nextChar]; 
  cout << "\n"; 

  return 0; 
} 

