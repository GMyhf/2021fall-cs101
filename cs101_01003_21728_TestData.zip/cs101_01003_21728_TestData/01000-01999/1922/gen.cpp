#include "iostream.h"
#include "string.h"
#include "stdlib.h"

int main()
{
	int i,t,seg;
	cout<<100<<endl;
	for (i=0;i<100;i++)
	{
		t=rand();
		t=t%11+15;
		cout<<t<<"	";
		t=rand();
		t=t%1200;
		cout<<t<<endl;
	}
	
	cout<<1000<<endl;
	for (i=0;i<1000;i++)
	{
		t=rand();
		t=t%21+10;
		cout<<t<<"	";
		t=rand();
		t=t%600;
		seg=rand();
		if (seg%2)
			cout<<t<<endl;
		else
			cout<<-t<<endl;
	}

	cout<<10000<<endl;
	for (i=0;i<10000;i++)
	{
		t=rand();
		t=t%40+1;
		cout<<t<<"	";
		t=rand();
		t=t%1200;
		seg=rand();
		if (seg%2)
			cout<<t<<endl;
		else
			cout<<-t<<endl;
	}

}
		

	
