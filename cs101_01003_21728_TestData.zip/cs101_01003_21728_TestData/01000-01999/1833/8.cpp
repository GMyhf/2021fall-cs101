#include<stdio.h>

#define MAXN 1024

int dat[MAXN];
int n, k;

void read_it()
{
	scanf( "%d %d", &n, &k );

	for( int i = 0; i < n; ++i )
		scanf( "%d", &dat[i] );
}

void make_it()
{
	if( n == 1 )
		return;

	int pos = n - 2;

	for( ; pos >= 0 && dat[pos] > dat[pos + 1]; --pos );

	if( pos >= 0 )
	{
		int pos2 = pos + 1;

		for( int i = pos + 2; i < n; ++i )
			if( dat[i] < dat[pos2] && dat[i] > dat[pos] )
				pos2 = i;

		int tmp = dat[pos];
		dat[pos] = dat[pos2];
		dat[pos2] = tmp;
	}

	for( int i = 0; i < ( n - pos ) / 2; ++i )
	{
		int tmp = dat[ pos + i + 1 ];
		dat[ pos + i + 1 ] = dat[ n - i - 1 ];
		dat[ n - i - 1 ] = tmp;
	}
}

void get_result()
{
	printf( "%d", dat[0] );

	for( int i = 1; i < n; ++i )
		printf( " %d", dat[i] );

	putchar( '\n' );
}

int main()
{
	int num;

	//freopen( "8.in", "r", stdin );
	//freopen( "out1", "w", stdout );

	scanf( "%d", &num );

	while( num-- )
	{
		read_it();

		for( int i = 0; i < k; ++i )
			make_it();
		
		get_result();
	}

	return 0;
}