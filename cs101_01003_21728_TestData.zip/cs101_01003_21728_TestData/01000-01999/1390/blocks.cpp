/*
    Blocks

    Sample Solution

    by Rongjing Xiang, translated by Rujia Liu
    
    * Algorithm:
	Dynamic programming. The time complexity is O(n^4), but by using some techniques, it can perform very well on average.
	
	* About test data:
	case 1/2: special
	caes 3: Preserving the color with most boxes will produce wrong answer.
	case 4/5: similar layout, but completely different strategy. the prevents people from using single greedy method.
	case 6-9: big tests. there are two special cases. case 9 is the worst case for this algorithm
	case 10: some people will directly check case 9, or after some heavy computations, stop and output 10100. This case is designed for those... :)))

*/

#include<stdio.h>
#include<string.h>
#define	MAXN 201
int f[MAXN][MAXN][MAXN];
int l[MAXN], c[MAXN], p[MAXN], t[MAXN];
int n;

void init()
{
	int i, j, k, n1;
	scanf("%d", &n1);
	n = 0;
	c[0] = 0;
	l[0] = 0;
	memset(t, 0, sizeof(t));
	for(i = 1; i <= n1; i++){
		scanf("%d", &j);
		if(c[n] == j) l[n]++;
		else{
			n++;
			l[n] = 1;
			c[n] = j;
			p[n] = 0;
			for(k = n-1; k >= 1; k--)
				if(c[k] == j){
					p[n] = k;
					break;
				}
		}
	}
	for(i = 1; i <= n; i++)
		for(j = i+1; j <= n; j++)
			if(c[i] == c[j])
				t[i] += l[j];
}

void find()
{
	int i, j, k, num, max, s;
	memset(f, 0, sizeof(f));
	for(j = 1; j <= n; j++)
		for(i = 1; i <= j; i++)
			for(num = 0; num <= t[j]; num++){
				max = f[i][j-1][0] + (l[j]+num)*(l[j]+num);
				k = p[j];
				while(k >= i){
					s = f[i][k][num+l[j]] + f[k+1][j-1][0];
					if(s > max) max = s;
					k = p[k];
				}
				f[i][j][num] = max;
			}
}

int main()
{
	int casecount, currentcase;
//	freopen("blocks.in","r",stdin);
//	freopen("blocks.out","w",stdout);
	scanf("%d", &casecount);
	for(currentcase = 1; currentcase <= casecount; currentcase++){
		init();
		find();
		printf("Case %d: %d\n", currentcase, f[1][n][0]);
	}
	return 0;
}