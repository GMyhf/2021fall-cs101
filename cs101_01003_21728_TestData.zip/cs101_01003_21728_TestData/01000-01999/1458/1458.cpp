#include <iostream>
#include <sstream>
#include <vector>
using namespace std;

int main()
{
    string line;
    while (getline(cin, line)) {
        istringstream iss(line);
        string strX, strZ;
        iss >> strX >> strZ;

        int nXlen=strX.size(), nZlen=strZ.size();
        vector<int> xArr(nXlen), zArr(nZlen);
        for (int i=0; i<nXlen; i++) {
            int j;
            for (j=0; j<nZlen; j++) {
                // not equal, pick the next one in Z
                if (i==nXlen) { 
                    int m;
                    for (m=0; m<nXlen; m++) {
                        if (xArr[m]==0 )  break;
                    }

                    if (m==nXlen) break;
                    i = m; 
                    continue;
                }

                // not equal, pick the next one in X
                if (strZ[j] != strX[i]) {
                    i++; j--; 
                    continue;
                }

                // lable what I have done
                for (int m=0; m<=i; m++) {
                    if (xArr[m]==0) xArr[m]=1;
                }


                if (j==0) {
                    zArr[j] =1; i++; 
                    continue;
                }
                for (int k=0; k<j; k++)
                    if (zArr[k]+1>zArr[j]) 
                        zArr[j] = zArr[k] + 1;

                i++;
            }

            // have checked all chars in Z
            if (j==strZ.size()) break;
        }


        int nMax=0;
        for (int i=0; i<nZlen; i++)
            if (zArr[i] > nMax) nMax = zArr[i];

        cout << nMax << endl;
    }
}
