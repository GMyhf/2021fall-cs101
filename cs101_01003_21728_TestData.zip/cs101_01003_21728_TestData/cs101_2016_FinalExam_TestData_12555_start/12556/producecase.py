from random import Random
def random_str(randomlength=8):
	output = open(filename + ".in", "w+")
    str = ''
    chars = 'AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuVvWwXxYyZz'
    length = len(chars) - 1
    random = Random()
    for i in range(randomlength):
        str+=chars[random.randint(0, length)]
    out.write(str)

filename = "4"
random_str(100)
input = open(filename + ".in")
sentence = input.readlines()[0].lower()
list = []
pre = sentence[0]
count = 1
for i in range(1, len(sentence)):
	if sentence[i] != pre:
		list.append('(' + pre + ',' + str(count) + ')')
		pre = sentence[i]
		count = 1
	else:
		count += 1
list.append('(' + pre + ',' + str(count) + ')')
with open(filename + ".out", 'w+') as output:
	output.write(''.join(list))