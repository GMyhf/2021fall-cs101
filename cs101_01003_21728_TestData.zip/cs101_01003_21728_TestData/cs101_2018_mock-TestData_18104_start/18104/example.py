g=[int(i) for i in input().split()]
s=[int(i) for i in input().split()]

g=sorted(g,reverse=True)
s=sorted(s,reverse=True)
i,j=[0,0]
l1,l2=[len(g),len(s)]
res=0
while i<l1 and j<l2:
    if(s[j]>=g[i]):
        res+=1
        i+=1
        j+=1
    else:
        i+=1
print(res)