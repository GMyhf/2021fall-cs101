import math

def isPrime(n):
	if n <= 1:
		return False
	for i in range(2, int(math.sqrt(n)) + 1):
		if n % i == 0:
			return False
	return True

T = int(input())
while T!=0:
	T -= 1
	ans = []
	start, end = map(int, input().split())
	for i in range(start, end+1):
		if isPrime(i):
			ans.append(i)
	if len(ans) != 0:
		print(' '.join(map(str, ans)))
	else:
		print(-1)