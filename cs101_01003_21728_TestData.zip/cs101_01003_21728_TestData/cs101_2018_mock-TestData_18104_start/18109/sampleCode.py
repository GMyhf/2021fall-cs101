sentence = input().lower()
list = []
dic={}
for i in range(len(sentence)):
	if(dic.has_key(sentence[i])):
		dic[sentence[i]]+=1
	else:
		dic[sentence[i]] = 1

chars_out=''
chars_num=0
for key in dic:
	if(dic[key]>chars_num):
		chars_out=key
		chars_num=dic[key]

print(chars_out + " " + str(chars_num))