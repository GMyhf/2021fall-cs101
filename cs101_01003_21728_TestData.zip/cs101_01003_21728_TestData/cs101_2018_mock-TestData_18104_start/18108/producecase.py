from random import Random
import math

def produce(T, filename):
	random = Random()
	with open(filename+".in", 'w+') as output:
		output.write(str(T)+"\n")
		for t in range(T):
			N = random.randint(1, 50)
			M = random.randint(1, 50)
			output.write(str(N) + " " + str(M) + "\n")
			tmpStr='.W..'
			for j in range(N):
				for i in range(M):
					output.write(tmpStr[(random.randint(0, 3))])
				output.write("\n")

dir = [[-1, 0], [1, 0], [0, -1], [0, 1], [-1, -1], [-1, 1], [1, -1], [1, 1]]
def dfs(x, y):
	if x < 0 or x >= N or y < 0 or y >= M or board[x][y] != 'W':
		return
	board[x][y] = '.'
	for i in range(len(dir)):
		dfs(x + dir[i][0], y + dir[i][1])
	


filename="4"
produce(50, filename)

input = open(filename+".in")
output = open(filename + ".out", "w+")
lines = input.readlines()

T = int(lines[0])
l = 1
while l < len(lines):
	N, M = map(int, lines[l].split())
	l += 1
	board = []
	ans = 0
	for i in range(N):
		board.append(list(lines[l]))
		l += 1
	for i in range(N):
		for j in range(M):
			if board[i][j] == 'W':
				ans += 1
				dfs(i, j)
	output.write(str(ans)+"\n")
